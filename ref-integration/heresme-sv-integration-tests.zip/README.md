# Here's Me Server - Integration Tests

このパッケージには、Here's Me Serverの結合テストが含まれています。

## クイックスタート

1. リポジトリをクローン
2. このパッケージを展開
3. 依存パッケージをインストール
4. 結合テストを実行

詳細は **INTEGRATION_TEST_GUIDE.md** を参照してください。

## 実行手順

詳細な手順は別紙 **結合テスト実行手順.md** を参照してください。

## ドキュメント

- `INTEGRATION_TEST_GUIDE.md` - 結合テスト実行ガイド
- `tests/integration/java/README.md` - Java結合テスト詳細
- `tests/integration/java/KNOWN_BUGS.md` - 既知の不具合
- `tests/integration/java/TEST_EXECUTION_REPORT.md` - テスト実行レポート
